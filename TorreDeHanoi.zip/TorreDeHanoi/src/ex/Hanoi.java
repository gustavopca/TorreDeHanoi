package ex;
import java.util.Stack;
public class Hanoi {

	public static void main(String[] args) {
		
		Stack<Integer> torre1 = new Stack<>();
		Stack<Integer> torre2 = new Stack<>();
		Stack<Integer> torre3 = new Stack<>();
		
		torre1.push(3);
		torre1.push(2);
		torre1.push(1);
		
		System.out.println("Torre 1: " + torre1 + " Torre 2: " + torre2 + " Torre 3: " + torre3);
		
		torreDeHanoi(torre1.size(), torre1, torre2, torre3);
	}

	public static void torreDeHanoi(int n, Stack<Integer> t1, 
			Stack<Integer> t2, Stack<Integer> t3){
		
		if (n > 0){
			torreDeHanoi(n-1, t1, t3, t2);
			t3.push(t1.pop());
			System.out.println("Torre 1: " + t1 + " Torre 2: " + t2 + " Torre 3: " + t3);
			torreDeHanoi(n-1, t2, t1, t3);
		}
		
	}
}
